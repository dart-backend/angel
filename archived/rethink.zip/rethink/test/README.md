# Tests

The tests expect you to have installed RethinkDB. You must have a `test` database
available, and a server ready at the default port.

Also, the tests expect a table named `todos`.