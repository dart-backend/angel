# Change Log

## 2.0.0

* Migrated to support Dart >= 2.12 NNBD

## 1.0.1

* Explicitly extend `Service<Id, T>`.
* Override `readData`.
* Use `Service<Id, Map<String, dynamic>>` for `inner`, instead of just
`Service<Id, Map>`.

## 1.0.0

* Initial version.
