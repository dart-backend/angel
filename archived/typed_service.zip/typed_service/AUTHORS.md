Primary Authors
===============

* __[Thomas Hii](dukefirehawk.apps@gmail.com)__

    Thomas is the current maintainer of the code base. He has refactored and migrated the 
    code base to support NNBD.

* __[Tobe O](thosakwe@gmail.com)__

    Tobe has written much of the original code prior to NNBD migration. He has moved on and
    is no longer involved with the project.
