# Change Log

## 2.0.0

* Migrated to support Dart >= 2.12 NNBD

## 1.0.0

* Initial checkin
