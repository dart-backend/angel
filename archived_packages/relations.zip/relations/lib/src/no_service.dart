ArgumentError noService(Pattern path) =>
    ArgumentError("No service exists at path '$path'.");
